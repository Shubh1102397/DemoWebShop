package contruct1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.List;

public class ProductDetailsTests {
    WebDriver driver;
    WebDriverWait wait;
    String baseUrl = "https://demowebshop.tricentis.com/";
    String productName;
    
    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        navigateToProduct();
    }

    private void navigateToProduct() {
        driver.get(baseUrl + "electronics");
        
        WebElement productLink = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.cssSelector(".product-title a")
            )
        );
        productName = productLink.getText();
        productLink.click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector(".product-name h1")
        ));
    }

    @Test(priority = 1)
    public void testProductPageLoads() {
        Assert.assertTrue(
            driver.getCurrentUrl().contains("/product/"),
            "Not on product details page"
        );
        Assert.assertTrue(
            driver.findElement(By.cssSelector(".product-name h1")).isDisplayed(),
            "Product name not displayed"
        );
    }

    @Test(priority = 2)
    public void testProductDetails() {
        String actualName = driver.findElement(
            By.cssSelector(".product-name h1")
        ).getText();
        
        String actualPrice = driver.findElement(
            By.cssSelector(".product-price span")
        ).getText();
        
        Assert.assertFalse(actualName.isEmpty(), "Product name is empty");
        Assert.assertTrue(
            actualPrice.matches("^\\$\\d+(\\.\\d{2})?$"), 
            "Invalid price format"
        );
    }

    @Test(priority = 3)
    public void testProductImages() {
        List<WebElement> thumbnails = driver.findElements(
            By.cssSelector(".picture-thumbs a")
        );
        Assert.assertFalse(thumbnails.isEmpty(), "No thumbnails found");
        
        WebElement mainImage = driver.findElement(
            By.cssSelector(".product-image img")
        );
        Assert.assertTrue(mainImage.isDisplayed(), "Main image missing");
        
        // Test image zoom if available
        try {
            new Actions(driver).moveToElement(mainImage).perform();
            if(!driver.findElements(By.cssSelector(".zoomWindow")).isEmpty()) {
                Assert.assertTrue(
                    driver.findElement(By.cssSelector(".zoomWindow")).isDisplayed(),
                    "Zoom not working"
                );
            }
        } catch (Exception e) {
            System.out.println("Zoom functionality not available");
        }
    }

    @Test(priority = 4)
    public void testAddToCart() {
        String addToCartButton = "input[value='Add to cart']";
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector(addToCartButton)
        )).click();
        
        WebElement notification = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".bar-notification.success")
            )
        );
        Assert.assertTrue(
            notification.getText().toLowerCase().contains("added"),
            "Add to cart notification missing"
        );
    }

    @Test(priority = 5)
    public void testAddToWishlist() {
        String wishlistButton = "input[value='Add to wishlist']";
        if(!driver.findElements(By.cssSelector(wishlistButton)).isEmpty()) {
            driver.findElement(By.cssSelector(wishlistButton)).click();
            WebElement notification = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector(".bar-notification.success")
                )
            );
            Assert.assertTrue(
                notification.getText().toLowerCase().contains("wishlist"),
                "Wishlist notification missing"
            );
        } else {
            System.out.println("Wishlist button not available for this product");
        }
    }

    @Test(priority = 6)
    public void testBackToList() {
        driver.findElement(By.cssSelector(".back-link a")).click();
        Assert.assertTrue(
            wait.until(ExpectedConditions.urlContains("/electronics")),
            "Not redirected to product list"
        );
    }

    @AfterMethod
    public void tearDown() {
        if(driver != null) {
            driver.quit();
        }
    }
}