package contruct1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class HomepageNavigationTests {
	 WebDriver driver;
	    String url = "https://demowebshop.tricentis.com/";
	    String validKeyword = "Laptop";
	    String invalidKeyword = "XYZ123";

	    @BeforeMethod
	    public void setup() {
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get(url);
	    }

	    // Test Case 01: Verify homepage loads successfully
	    @Test(priority = 1)
	    public void testHomepageLoad() {
	        Assert.assertTrue(driver.getTitle().contains("Demo Web Shop"));
	        Assert.assertTrue(driver.findElement(By.className("header-logo")).isDisplayed());
	    }

	    // Test Case 02: Validate header links redirect correctly
	    @Test(priority = 2)
	    public void testHeaderLinks() {
	        String[][] links = {{"Login", "login"}, {"Register", "register"}, {"Shopping cart", "cart"}};
	        for (String[] link : links) {
	            driver.findElement(By.linkText(link[0])).click();
	            Assert.assertTrue(driver.getCurrentUrl().contains(link[1]));
	            driver.navigate().back();
	        }
	    }

	    // Test Case 03: Verify footer links redirect correctly
	    @Test(priority = 3)
	    public void testFooterLinks() {
	        String[][] links = {{"About Us", "about-us"}, {"Contact Us", "contactus"}};
	        for (String[] link : links) {
	            try {
	                driver.findElement(By.linkText(link[0])).click();
	                Assert.assertTrue(driver.getCurrentUrl().contains(link[1]));
	                driver.navigate().back();
	            } catch (Exception e) {
	                Assert.fail("Link '" + link[0] + "' is broken (404).");
	            }
	        }
	    }

	    // Test Case 04: Test search bar with a valid keyword
	    @Test(priority = 4)
	    public void testSearchValidKeyword() {
	        WebElement searchBox = driver.findElement(By.id("small-searchterms"));
	        searchBox.clear();
	        searchBox.sendKeys(validKeyword);
	        driver.findElement(By.cssSelector("input[value='Search']")).click();
	        Assert.assertFalse(driver.getPageSource().contains("No products were found"));
	    }

	    // Test Case 05: Test search bar with an invalid keyword
	    @Test(priority = 5)
	    public void testSearchInvalidKeyword() {
	        WebElement searchBox = driver.findElement(By.id("small-searchterms"));
	        searchBox.clear();
	        searchBox.sendKeys(invalidKeyword);
	        driver.findElement(By.cssSelector("input[value='Search']")).click();
	        Assert.assertTrue(driver.getPageSource().contains("No products were found"));
	    }

	    // Test Case 06: Test search bar with empty input
	    @Test(priority = 6)
	    public void testSearchEmptyInput() {
	        WebElement searchBox = driver.findElement(By.id("small-searchterms"));
	        searchBox.clear();
	        driver.findElement(By.cssSelector("input[value='Search']")).click();
	        WebElement errorMsg = new WebDriverWait(driver, Duration.ofSeconds(5))
	                .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".warning")));
	        Assert.assertTrue(errorMsg.getText().contains("Please enter a search term"));
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }

}
