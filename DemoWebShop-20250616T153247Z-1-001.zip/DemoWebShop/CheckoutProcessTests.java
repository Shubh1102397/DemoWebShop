package contruct1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class CheckoutProcessTests {
	WebDriver driver;
    WebDriverWait wait;
    String baseUrl = "https://demowebshop.tricentis.com/";
    String productName = "Smartphone";

    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        addProductToCart(); // Precondition for most tests
    }

    // Precondition: Add product to cart
    private void addProductToCart() {
        driver.get(baseUrl);
        
        // Find first available product instead of hardcoded "Smartphone"
        WebElement product = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.cssSelector(".product-title a")
            )
        );
        productName = product.getText();
        product.click();
        
        // Add to cart
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector(".add-to-cart-button")
        )).click();
        
        wait.until(ExpectedConditions.textToBe(
            By.cssSelector(".cart-qty"), "(1)"
        ));
    }
    // TC-27: Proceed to checkout as guest
    @Test(priority = 1)
    public void testGuestCheckout() {
        driver.get(baseUrl + "cart");
        driver.findElement(By.id("checkout")).click();
        driver.findElement(By.cssSelector("input[value='Checkout as Guest']")).click();
        Assert.assertTrue(
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("billing-address-form"))).isDisplayed(),
            "Address form not displayed"
        );
    }

    // TC-28: Fill address form and proceed
    @Test(priority = 2, dependsOnMethods = "testGuestCheckout")
    public void testValidAddressSubmission() {
        testGuestCheckout(); // Ensure in checkout flow
        
        // Fill address form
        driver.findElement(By.id("BillingNewAddress_FirstName")).sendKeys("John");
        driver.findElement(By.id("BillingNewAddress_LastName")).sendKeys("Doe");
        driver.findElement(By.id("BillingNewAddress_Email")).sendKeys("john.doe@test.com");
        new Select(driver.findElement(By.id("BillingNewAddress_CountryId"))).selectByVisibleText("United States");
        driver.findElement(By.id("BillingNewAddress_City")).sendKeys("New York");
        driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys("123 Main St");
        driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys("10001");
        driver.findElement(By.id("BillingNewAddress_PhoneNumber")).sendKeys("5551234567");
        driver.findElement(By.cssSelector("input[onclick='Billing.save()']")).click();

        Assert.assertTrue(
            wait.until(ExpectedConditions.urlContains("/checkout/payment")),
            "Payment page not loaded"
        );
    }

    // TC-29: Test invalid address submission
    @Test(priority = 3)
    public void testInvalidAddress() {
        testGuestCheckout(); // Ensure in checkout flow
        driver.findElement(By.cssSelector("input[onclick='Billing.save()']")).click();

        WebElement error = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".field-validation-error"))
        );
        Assert.assertTrue(
            error.getText().contains("required"),
            "Error message not displayed for missing fields"
        );
    }

    // TC-30: Select payment method
    @Test(priority = 4, dependsOnMethods = "testValidAddressSubmission")
    public void testPaymentMethodSelection() {
        testValidAddressSubmission(); // Ensure in payment step
        
        driver.findElement(By.id("paymentmethod_1")).click(); // Credit Card
        driver.findElement(By.cssSelector("input[onclick='PaymentMethod.save()']")).click();

        Assert.assertTrue(
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("checkout-confirm-order-load"))).isDisplayed(),
            "Order summary not displayed"
        );
    }

    // TC-31: Place order and verify confirmation
    @Test(priority = 5, dependsOnMethods = "testPaymentMethodSelection")
    public void testOrderConfirmation() {
        testPaymentMethodSelection(); // Ensure in confirmation step
        driver.findElement(By.cssSelector("input[onclick='ConfirmOrder.save()']")).click();

        WebElement confirmation = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".order-completed"))
        );
        Assert.assertTrue(
            confirmation.getText().contains("Your order has been successfully processed"),
            "Order confirmation missing"
        );
        Assert.assertTrue(
            driver.findElement(By.cssSelector(".order-number")).getText().matches("ORDER NUMBER: \\d+"),
            "Order number not generated"
        );
    }

    // TC-32: Verify order confirmation email (simulated)
    @Test(priority = 6, dependsOnMethods = "testOrderConfirmation")
    public void testConfirmationEmail() {
        // Note: Actual email validation requires external tools (e.g., MailSlurp)
        // This is a simulated check using UI confirmation
        Assert.assertTrue(
            driver.findElement(By.cssSelector(".order-completed")).getText().contains("email"),
            "Email confirmation reference missing"
        );
    }

    // TC-33: Test checkout with empty cart
    @Test(priority = 7)
    public void testEmptyCartCheckout() {
        // Empty cart
        driver.get(baseUrl + "cart");
        driver.findElement(By.cssSelector("input[name='removefromcart']")).click();
        driver.findElement(By.cssSelector("input[name='updatecart']")).click();

        driver.findElement(By.id("checkout")).click();
        WebElement error = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".validation-summary-errors"))
        );
        Assert.assertTrue(
            error.getText().contains("empty"),
            "Empty cart error missing"
        );
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

}
