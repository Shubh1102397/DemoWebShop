package contruct1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.UUID;

public class UserAccountTests {
	
	 WebDriver driver;
	    WebDriverWait wait;
	    String baseUrl = "https://demowebshop.tricentis.com/";
	    String email = "user_" + UUID.randomUUID().toString().substring(0, 8) + "@test.com";
	    String password = "Password123!";

	    @BeforeMethod
	    public void setup() {
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    // TC-34: Register a new user
	    @Test(priority = 1)
	    public void testUserRegistration() {
	        driver.get(baseUrl + "register");
	        driver.findElement(By.id("gender-male")).click();
	        driver.findElement(By.id("FirstName")).sendKeys("John");
	        driver.findElement(By.id("LastName")).sendKeys("Doe");
	        driver.findElement(By.id("Email")).sendKeys(email);
	        driver.findElement(By.id("Password")).sendKeys(password);
	        driver.findElement(By.id("ConfirmPassword")).sendKeys(password);
	        driver.findElement(By.id("register-button")).click();

	        WebElement result = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".registration-result-page"))
	        );
	        Assert.assertTrue(
	            result.getText().contains("Your registration completed"),
	            "Registration failed"
	        );
	    }

	    // TC-35: Test registration with invalid data
	    @Test(priority = 2, dependsOnMethods = "testUserRegistration")
	    public void testDuplicateEmailRegistration() {
	        driver.get(baseUrl + "register");
	        driver.findElement(By.id("Email")).sendKeys(email); // Duplicate email
	        driver.findElement(By.id("register-button")).click();

	        WebElement error = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".field-validation-error"))
	        );
	        Assert.assertTrue(
	            error.getText().contains("already exists"),
	            "Duplicate email error missing"
	        );
	    }

	    // TC-36: Log in with valid credentials
	    @Test(priority = 3)
	    public void testValidLogin() {
	        driver.get(baseUrl + "login");
	        driver.findElement(By.id("Email")).sendKeys(email);
	        driver.findElement(By.id("Password")).sendKeys(password);
	        driver.findElement(By.cssSelector("input[value='Log in']")).click();

	        Assert.assertTrue(
	            wait.until(ExpectedConditions.urlContains("customer/info")),
	            "Login failed or wrong redirect"
	        );
	    }

	    // TC-37: Log in with invalid credentials
	    @Test(priority = 4)
	    public void testInvalidLogin() {
	        driver.get(baseUrl + "login");
	        driver.findElement(By.id("Email")).sendKeys("invalid@test.com");
	        driver.findElement(By.id("Password")).sendKeys("WrongPassword123!");
	        driver.findElement(By.cssSelector("input[value='Log in']")).click();

	        WebElement error = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".validation-summary-errors"))
	        );
	        Assert.assertTrue(
	            error.getText().contains("No customer account found"),
	            "Invalid login error missing"
	        );
	    }

	    // TC-38: Log out and verify redirection
	    @Test(priority = 5, dependsOnMethods = "testValidLogin")
	    public void testLogout() {
	        testValidLogin(); // Ensure logged in
	        driver.findElement(By.linkText("Log out")).click();

	        Assert.assertTrue(
	            wait.until(ExpectedConditions.urlToBe(baseUrl)),
	            "Logout redirect failed"
	        );
	        Assert.assertTrue(
	            driver.findElements(By.linkText("Log out")).isEmpty(),
	            "Logout button still visible"
	        );
	    }

	    // TC-39: Update user profile
	    @Test(priority = 6, dependsOnMethods = "testValidLogin")
	    public void testProfileUpdate() {
	        testValidLogin(); // Ensure logged in
	        driver.get(baseUrl + "customer/info");

	        WebElement phone = driver.findElement(By.id("Phone"));
	        phone.clear();
	        phone.sendKeys("555-987-6543");
	        driver.findElement(By.cssSelector("input[value='Save']")).click();

	        WebElement message = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".content"))
	        );
	        Assert.assertTrue(
	            message.getText().contains("updated"),
	            "Profile update confirmation missing"
	        );
	    }

	    // TC-40: Test password reset (simulated)
	    @Test(priority = 7)
	    public void testPasswordReset() {
	        driver.get(baseUrl + "passwordrecovery");
	        driver.findElement(By.id("Email")).sendKeys(email);
	        driver.findElement(By.cssSelector("input[value='Recover']")).click();

	        WebElement message = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".content"))
	        );
	        Assert.assertTrue(
	            message.getText().contains("Email with instructions has been sent"),
	            "Password reset email not triggered"
	        );
	    }

	    // TC-41: Verify order history
	    @Test(priority = 8, dependsOnMethods = {"testValidLogin", "testUserRegistration"})
	    public void testOrderHistory() {
	        testValidLogin(); // Ensure logged in
	        driver.get(baseUrl + "customer/orders");

	        WebElement history = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".order-list"))
	        );
	        Assert.assertTrue(
	            history.getText().contains("Order Number") || history.getText().contains("No orders"),
	            "Order history section missing"
	        );
	    }

	    // TC-42: Add product to wishlist
	    @Test(priority = 9, dependsOnMethods = "testValidLogin")
	    public void testAddToWishlist() {
	        testValidLogin(); // Ensure logged in
	        driver.get(baseUrl + "digital-downloads");
	        driver.findElement(By.cssSelector("input[value='Add to wishlist']")).click();

	        WebElement message = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".content"))
	        );
	        Assert.assertTrue(
	            message.getText().contains("wishlist"),
	            "Wishlist addition confirmation missing"
	        );
	    }

	    // TC-43: Remove product from wishlist
	    @Test(priority = 10, dependsOnMethods = "testAddToWishlist")
	    public void testRemoveFromWishlist() {
	        testAddToWishlist(); // Ensure product is in wishlist
	        driver.get(baseUrl + "wishlist");
	        driver.findElement(By.name("removefromcart")).click();
	        driver.findElement(By.name("updatecart")).click();

	        WebElement message = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".content"))
	        );
	        Assert.assertTrue(
	            message.getText().contains("empty") || message.getText().contains("updated"),
	            "Wishlist removal confirmation missing"
	        );
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }
	}


