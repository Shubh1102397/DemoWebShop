package contruct1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class ResponsivenessTests {
	 WebDriver driver;
	    WebDriverWait wait;
	    String baseUrl = "https://demowebshop.tricentis.com/";

	    // Configure device emulation
	    private ChromeOptions getDeviceOptions(String deviceType) {
	        Map<String, String> mobileEmulation = new HashMap<>();
	        ChromeOptions options = new ChromeOptions();

	        switch (deviceType.toLowerCase()) {
	            case "tablet":
	                mobileEmulation.put("deviceName", "iPad Pro");
	                break;
	            case "mobile":
	                mobileEmulation.put("deviceName", "Pixel 5");
	                break;
	            default: // Desktop
	                return options;
	        }
	        options.setExperimentalOption("mobileEmulation", mobileEmulation);
	        return options;
	    }

	    @BeforeMethod
	    @Parameters("deviceType")
	    public void setup(@Optional("desktop") String deviceType) {
	        try {
	            WebDriverManager.chromedriver().setup();
	            driver = new ChromeDriver(getDeviceOptions(deviceType));
	            driver.manage().window().maximize();
	            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        } catch (Exception e) {
	            Assert.fail("Failed to initialize driver for device: " + deviceType, e);
	        }
	    }

	    // TC-44: Desktop layout verification
	    @Test(priority = 1)
	    public void testDesktopLayout() {
	        driver.get(baseUrl);
	        Assert.assertTrue(
	            driver.findElement(By.cssSelector(".header-menu")).isDisplayed(),
	            "Desktop menu not visible"
	        );
	        assertNoOverlappingElements();
	    }

	    // TC-45: Tablet layout verification
	    @Test(priority = 2)
	    public void testTabletLayout() {
	        driver.get(baseUrl);
	        // Verify responsive elements
	        Assert.assertTrue(
	            driver.findElement(By.cssSelector(".menu-toggle")).isDisplayed(),
	            "Tablet menu toggle missing"
	        );
	        assertTouchTargetSize(48); // Minimum recommended touch target size
	    }

	    // TC-46: Mobile layout verification
	    @Test(priority = 3)
	    public void testMobileLayout() {
	        driver.get(baseUrl);
	        // Verify mobile-specific elements
	        WebElement menuToggle = wait.until(
	            ExpectedConditions.elementToBeClickable(By.cssSelector(".menu-toggle"))
	        );
	        menuToggle.click();
	        Assert.assertTrue(
	            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mobile-menu")))
	                .isDisplayed(),
	            "Mobile menu not expanding"
	        );
	        assertFontSizeAdjustment();
	    }

	    // TC-47: Mobile product browsing
	    @Test(priority = 4)
	    public void testMobileProductBrowsing() {
	        driver.get(baseUrl + "electronics");
	        // Verify scroll and tap
	        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,500)");
	        WebElement product = wait.until(
	            ExpectedConditions.elementToBeClickable(By.cssSelector(".product-item"))
	        );
	        product.click();
	        Assert.assertTrue(
	            driver.getCurrentUrl().contains("/product/"),
	            "Product detail page not opened"
	        );
	    }

	    // TC-48: Mobile cart functionality
	    @Test(priority = 5)
	    public void testMobileCart() {
	        // Add product to cart
	        driver.get(baseUrl + "smartphone");
	        driver.findElement(By.cssSelector(".add-to-cart-button")).click();
	        wait.until(ExpectedConditions.textToBe(By.cssSelector(".cart-qty"), "(1)"));

	        // Open cart
	        driver.findElement(By.cssSelector(".cart-label")).click();
	        Assert.assertTrue(
	            driver.findElement(By.cssSelector(".cart-item")).isDisplayed(),
	            "Cart items not visible"
	        );
	    }

	    // TC-49: Mobile checkout process
	    @Test(priority = 6)
	    public void testMobileCheckout() {
	        testMobileCart(); // Ensure cart has items
	        driver.findElement(By.cssSelector(".checkout-button")).click();

	        // Verify form accessibility
	        WebElement emailField = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.id("BillingNewAddress_Email"))
	        );
	        Assert.assertTrue(
	            emailField.isEnabled(),
	            "Checkout form field not accessible"
	        );
	    }

	    // TC-50: Mobile menu navigation
	    @Test(priority = 7)
	    public void testMobileMenu() {
	        driver.get(baseUrl);
	        // Toggle menu twice to verify expand/collapse
	        WebElement menuToggle = driver.findElement(By.cssSelector(".menu-toggle"));
	        menuToggle.click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mobile-menu")));
	        menuToggle.click();
	        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".mobile-menu")));
	    }

	    // Helper: Check for overlapping elements
	    private void assertNoOverlappingElements() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        Boolean result = (Boolean) js.executeScript(
	            "var elems = document.querySelectorAll('*');" +
	            "for(var i=0; i<elems.length; i++){" +
	            "  for(var j=i+1; j<elems.length; j++){" +
	            "    var rect1 = elems[i].getBoundingClientRect();" +
	            "    var rect2 = elems[j].getBoundingClientRect();" +
	            "    if(!(rect1.right < rect2.left || rect1.left > rect2.right || " +
	            "         rect1.bottom < rect2.top || rect1.top > rect2.bottom)){" +
	            "      return false;" +
	            "    }" +
	            "  }" +
	            "} return true;"
	        );
	        Assert.assertTrue(result, "Overlapping elements detected");
	    }

	    // Helper: Verify touch target size
	    private void assertTouchTargetSize(int minSize) {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        Boolean result = (Boolean) js.executeScript(
	            "var buttons = document.querySelectorAll('button, a[href], input[type=\"submit\"]');" +
	            "for(var i=0; i<buttons.length; i++){" +
	            "  var rect = buttons[i].getBoundingClientRect();" +
	            "  if(rect.width < " + minSize + " || rect.height < " + minSize + "){" +
	            "    return false;" +
	            "  }" +
	            "} return true;"
	        );
	        Assert.assertTrue(result, "Touch targets smaller than " + minSize + "px detected");
	    }

	    // Helper: Check font size adjustment
	    private void assertFontSizeAdjustment() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        Boolean result = (Boolean) js.executeScript(
	            "var bodySize = parseInt(window.getComputedStyle(document.body).fontSize);" +
	            "return bodySize <= 16;" // Mobile typically uses smaller base font
	        );
	        Assert.assertTrue(result, "Font size not adjusted for mobile");
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }
	

}
