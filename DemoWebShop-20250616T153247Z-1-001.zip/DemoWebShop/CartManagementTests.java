package contruct1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

//import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class CartManagementTests {
	 WebDriver driver;
	    WebDriverWait wait;
	    String baseUrl = "https://demowebshop.tricentis.com/";
	    String productName = "Smartphone";
	    double productPrice = 599.00;

	    @BeforeMethod
	    public void setup() {
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        addProductToCart(); // Precondition for most tests
	    }

	    // Precondition: Add product to cart
	    private void addProductToCart() {
	        driver.get(baseUrl + "electronics");
	        driver.findElement(By.linkText(productName)).click();
	        driver.findElement(By.id("add-to-cart-button-43")).click();
	        wait.until(ExpectedConditions.textToBe(By.cssSelector(".cart-qty"), "(1)"));
	    }

	    // TC-19: Verify cart count updates
	    @Test(priority = 1)
	    public void testCartCountUpdate() {
	        Assert.assertEquals(
	            driver.findElement(By.cssSelector(".cart-qty")).getText(),
	            "(1)",
	            "Cart count not updated"
	        );
	    }

	    // TC-20: Verify correct products in cart
	    @Test(priority = 2)
	    public void testCartContents() {
	        driver.get(baseUrl + "cart");
	        Assert.assertTrue(
	            driver.findElement(By.cssSelector(".cart-item-row")).getText().contains(productName),
	            "Product missing in cart"
	        );
	    }

	    // TC-21: Verify cart total price
	    @Test(priority = 3)
	    public void testCartTotalPrice() {
	        driver.get(baseUrl + "cart");
	        double subtotal = Double.parseDouble(
	            driver.findElement(By.cssSelector(".cart-total-right")).getText().replace("$", "")
	        );
	        Assert.assertEquals(subtotal, productPrice, 0.01, "Subtotal mismatch");
	    }

	    // TC-22: Increase quantity
	    @Test(priority = 4)
	    public void testIncreaseQuantity() {
	        driver.get(baseUrl + "cart");
	        WebElement quantity = driver.findElement(By.cssSelector("input.qty-input"));
	        quantity.clear();
	        quantity.sendKeys("2");
	        driver.findElement(By.cssSelector("input[name='updatecart']")).click();

	        double updatedTotal = Double.parseDouble(
	            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".product-subtotal")))
	                .getText().replace("$", "")
	        );
	        Assert.assertEquals(updatedTotal, productPrice * 2, 0.01, "Total not updated correctly");
	    }

	    // TC-23: Decrease quantity
	    @Test(priority = 5)
	    public void testDecreaseQuantity() {
	        testIncreaseQuantity(); // First increase to 2
	        WebElement quantity = driver.findElement(By.cssSelector("input.qty-input"));
	        quantity.clear();
	        quantity.sendKeys("1");
	        driver.findElement(By.cssSelector("input[name='updatecart']")).click();

	        double updatedTotal = Double.parseDouble(
	            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".product-subtotal")))
	                .getText().replace("$", "")
	        );
	        Assert.assertEquals(updatedTotal, productPrice, 0.01, "Total not reverted correctly");
	    }

	    // TC-24: Remove product
	    @Test(priority = 6)
	    public void testRemoveProduct() {
	        driver.get(baseUrl + "cart");
	        driver.findElement(By.cssSelector("input[name='removefromcart']")).click();
	        driver.findElement(By.cssSelector("input[name='updatecart']")).click();

	        WebElement emptyMessage = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".order-summary-content"))
	        );
	        Assert.assertTrue(
	            emptyMessage.getText().contains("Your cart is empty"),
	            "Empty cart message missing"
	        );
	        Assert.assertEquals(
	            driver.findElement(By.cssSelector(".cart-qty")).getText(),
	            "(0)",
	            "Cart count not reset"
	        );
	    }

	    // TC-25: Continue Shopping
	    @Test(priority = 7)
	    public void testContinueShopping() {
	        driver.get(baseUrl + "cart");
	        driver.findElement(By.cssSelector(".continue-shopping-button")).click();
	        Assert.assertTrue(
	            wait.until(ExpectedConditions.urlToBe(baseUrl)),
	            "Not redirected to homepage"
	        );
	    }

	    // TC-26: Empty cart behavior
	    @Test(priority = 8)
	    public void testEmptyCart() {
	        testRemoveProduct(); // Ensure cart is empty
	        driver.get(baseUrl + "cart");
	        WebElement emptyMessage = driver.findElement(By.cssSelector(".order-summary-content"));
	        Assert.assertTrue(
	            emptyMessage.getText().contains("Your cart is empty"),
	            "Empty cart message not persistent"
	        );
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }

}
