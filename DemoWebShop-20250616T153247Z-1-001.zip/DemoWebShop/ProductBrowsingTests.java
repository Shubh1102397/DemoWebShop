package contruct1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.List;

public class ProductBrowsingTests {
	 WebDriver driver;
	    String url = "https://demowebshop.tricentis.com/";
	    WebDriverWait wait;

	    @BeforeMethod
	    public void setup() {
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get(url);
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    // Test Case 07: Verify all product categories are displayed
	    @Test(priority = 1)
	    public void testCategoriesDisplayed() {
	        List<WebElement> categories = driver.findElements(By.cssSelector(".block-category-navigation .list li a"));
	        Assert.assertTrue(categories.size() > 0, "No categories found");
	        // Verify specific categories (example)
	        Assert.assertTrue(categories.get(0).getText().contains("Books"));
	        Assert.assertTrue(categories.get(1).getText().contains("Electronics"));
	    }

	    // Test Case 08: Click a category and verify product list
	    @Test(priority = 2)
	    public void testCategoryNavigation() {
	        String category = "Electronics";
	        driver.findElement(By.linkText(category)).click();
	        Assert.assertTrue(driver.getCurrentUrl().contains("/electronics"));
	        List<WebElement> products = driver.findElements(By.cssSelector(".product-item"));
	        Assert.assertTrue(products.size() > 0, "No products displayed");
	    }

	    // Test Case 09: Apply price range filter
	    @Test(priority = 3)
	    public void testPriceFilter() {
	        navigateToCategory("Electronics");
	        driver.findElement(By.cssSelector("input[value='100']")).sendKeys("100");
	        driver.findElement(By.cssSelector("input[value='500']")).sendKeys("500");
	        driver.findElement(By.cssSelector("input[value='Filter']")).click();
	        
	        List<WebElement> prices = driver.findElements(By.cssSelector(".actual-price"));
	        for (WebElement price : prices) {
	            double productPrice = Double.parseDouble(price.getText());
	            Assert.assertTrue(productPrice >= 100 && productPrice <= 500, "Price out of range: " + productPrice);
	        }
	    }

	    // Test Case 10: Apply manufacturer filter
	    @Test(priority = 4)
	    public void testManufacturerFilter() {
	        navigateToCategory("Electronics");
	        driver.findElement(By.cssSelector("input[value='Apple']")).click();
	        driver.findElement(By.cssSelector("input[value='Filter']")).click();
	        
	        List<WebElement> products = driver.findElements(By.cssSelector(".product-item"));
	        for (WebElement product : products) {
	            Assert.assertTrue(product.getText().contains("Apple"), "Non-Apple product found");
	        }
	    }

	    // Test Case 11: Verify sorting functionality
	    @Test(priority = 5)
	    public void testSorting() {
	        navigateToCategory("Books");
	        Select sortDropdown = new Select(driver.findElement(By.id("products-orderby")));
	        sortDropdown.selectByVisibleText("Price: Low to High");
	        
	        List<WebElement> prices = driver.findElements(By.cssSelector(".actual-price"));
	        double prevPrice = 0;
	        for (WebElement price : prices) {
	            double currentPrice = Double.parseDouble(price.getText());
	            Assert.assertTrue(currentPrice >= prevPrice, "Prices not sorted low-to-high");
	            prevPrice = currentPrice;
	        }
	    }

	    // Test Case 12: Test pagination
	    @Test(priority = 6)
	    public void testPagination() {
	        navigateToCategory("Books");
	        String firstPageProduct = driver.findElement(By.cssSelector(".product-item:first-child .product-title")).getText();
	        driver.findElement(By.cssSelector(".next-page")).click();
	        wait.until(ExpectedConditions.invisibilityOfElementWithText(By.cssSelector(".product-item:first-child .product-title"), firstPageProduct));
	        Assert.assertNotEquals(
	            driver.findElement(By.cssSelector(".product-item:first-child .product-title")).getText(),
	            firstPageProduct,
	            "Pagination did not load new products"
	        );
	    }

	    private void navigateToCategory(String category) {
	        driver.findElement(By.linkText(category)).click();
	        wait.until(ExpectedConditions.urlContains(category.toLowerCase()));
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }

}
